package org.example;

/**
 * Test Project!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Test Project!" );
    }
}
