package org.example;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

import static org.openqa.selenium.By.*;

//Login.java
public class Login {

    protected WebDriver driver;
    public static String loginUrl = "http://localhost:8082/Campustagram/login";
    public static String loginUrlHomePage = "http://localhost:8082/Campustagram/dashboard";

    @Before
    public void setUp() {

        try {

            DesiredCapabilities capabilities = DesiredCapabilities.chrome();
            System.setProperty("webdriver.chrome.driver", "C:\\Users\\Asus\\IdeaProjects\\testProject\\drivers\\chromedriver.exe");
            driver = new ChromeDriver(capabilities);
            driver.manage().window().maximize();
            driver.manage().deleteAllCookies();

            //dynamic wait
            driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
            driver.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Test
    public void fullTest(){
        try {
            Test1_Login();
            Like();
            Search();
            HeaderButtons();
            Edit();
            LogOut();
            Thread.sleep(2000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void LogOut() {
        try{
            driver.findElement(By.xpath(".//*[@id=\"j_id_22\"]/ul/li[2]/a")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath(".//*[@id=\"j_id_22:j_id_31\"]")).click();


        }catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void Test6_LogOut() {
        try{
            Test1_Login();
            LogOut();;
            Thread.sleep(2000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void Like() {
        try{
            //like ve profil fotoğrafından profile gitme
            driver.findElement(By.xpath(".//*[@id=\"form:images:0:j_id_4i\"]")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath(".//*[@id=\"form:images:0:j_id_4a_header\"]/span/a")).click();
            Thread.sleep(2000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void Test2_Like() {
        try{
            Test1_Login();
            Like();
            Thread.sleep(2000);
    }catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void Search() {
        try{
            //ara ve profile git
            driver.findElement(By.xpath(".//*[@id=\"navbar-collapse\"]/ul/li[5]/a")).click();
            Thread.sleep(2000);
            driver.findElement(name("j_id_41:key")).sendKeys("salih");
            Thread.sleep(1000);
            driver.findElement(By.xpath(".//*[@id=\"j_id_41:j_id_44\"]")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath(".//*[@id=\"j_id_41:j_id_46\"]/div/ul/li/table/tbody/tr/td[1]")).click();
            Thread.sleep(2000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void Test4_Search() {
        try{
            Test1_Login();
            //ara ve profile git
            Search();
            Thread.sleep(2000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void HeaderButtons(){

        try {
            //kendi profil sayfasına gitme anasayfaya gitme
            driver.findElement(By.xpath(".//*[@id=\"navbar-collapse\"]/ul/li[4]/a")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath(".//*[@id=\"navbar-collapse\"]/ul/li[1]/a")).click();
            Thread.sleep(2000);
            //kullanıcı yönetimi butonu
            //*[@id="navbar-collapse"]/ul/li[6]
            driver.findElement(By.xpath(".//*[@id=\"navbar-collapse\"]/ul/li[6]")).click();
            Thread.sleep(1000);
            ///html/body/div[1]/header/nav/div/div[1]/a
            //Campustagram yazısından anasayfaya gitme
            driver.findElement(By.xpath("/html/body/div[1]/header/nav/div/div[1]/a")).click();
            Thread.sleep(2000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void Test5_HeaderButtons(){

        try {
            Test1_Login();
            HeaderButtons();
            Thread.sleep(1000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void Test1_Login() {

        try {
            driver.get(loginUrl);
            driver.findElement(name("username")).sendKeys("mineisik@gtu.edu.tr");
            Thread.sleep(1000);
            driver.findElement(name("password")).sendKeys("1");
            Thread.sleep(1000);
            driver.findElement(By.xpath(".//*[@id=\"j_id_1e\"]")).click();
            Thread.sleep(2000);



        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void Edit() {

        try {
            driver.findElement(By.xpath(".//*[@id=\"j_id_22\"]/ul/li[2]/a")).click();
            Thread.sleep(2000);


            //->bilgileri düzenle
            driver.findElement(By.xpath(".//*[@id=\"j_id_22\"]/ul/li[2]/ul/li[3]/a")).click();
            Thread.sleep(2000);
            //->doğum tarihini değiştir
            driver.findElement(name("main:dateOfBirth_input")).sendKeys("23-01-2017");
            Thread.sleep(1000);
            //->kaydet
            driver.findElement(By.xpath(".//*[@id=\"main:saveUser\"]")).click();
            Thread.sleep(2000);
            //*[@id="j_id_4z"]
            driver.findElement(By.xpath(".//*[@id=\"j_id_4z\"]")).click();
            Thread.sleep(2000);

            // ismi değiştir->geçersiz input 'a'
            driver.findElement(By.xpath(".//*[@id=\"main:lastName\"]")).clear();
            driver.findElement(By.xpath(".//*[@id=\"main:lastName\"]")).sendKeys("a");
            Thread.sleep(1000);
            driver.findElement(By.xpath(".//*[@id=\"main:saveUser\"]")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath(".//*[@id=\"j_id_4z\"]")).click();
            Thread.sleep(2000);
            // ismi değiştir->geçerli input 'ab'
            driver.findElement(By.xpath(".//*[@id=\"main:lastName\"]")).clear();
            driver.findElement(By.xpath(".//*[@id=\"main:lastName\"]")).sendKeys("ab");
            Thread.sleep(1000);
            driver.findElement(By.id("main:saveUser")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath(".//*[@id=\"j_id_4z\"]")).click();
            Thread.sleep(2000);
            //anasayfaya geri dön
            driver.findElement(By.xpath(".//*[@id=\"navbar-collapse\"]/ul/li[1]/a")).click();
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void Test3_Edit() {

        try {
            Test1_Login();
            Edit();
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }



    @After
    public void tearDown() throws Exception {

    }
}